using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using BankingLoanSystem.Database;
using BankingLoanSystem.Models;

namespace BankingLoanSystem.DataAccess
{
    public class LoanRepository
    {
        public bool CreateLoan(Loan loan, string loanType)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = @"INSERT INTO Loans (AccountNumber, LoanType, LoanAmount, InterestRate, DurationMonths, EMI)
                                   VALUES (@AccountNumber, @LoanType, @LoanAmount, @InterestRate, @DurationMonths, @EMI);
                                   SELECT CAST(SCOPE_IDENTITY() as int)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", loan.AccountNumber);
                        command.Parameters.AddWithValue("@LoanType", loanType);
                        command.Parameters.AddWithValue("@LoanAmount", loan.LoanAmount);
                        command.Parameters.AddWithValue("@InterestRate", loan.InterestRate);
                        command.Parameters.AddWithValue("@DurationMonths", loan.DurationMonths);
                        command.Parameters.AddWithValue("@EMI", loan.EMI);

                        int loanId = (int)command.ExecuteScalar();
                        loan.LoanId = loanId;

                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Loan> GetLoansByAccount(string accountNumber)
        {
            List<Loan> loans = new List<Loan>();

            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "SELECT * FROM Loans WHERE AccountNumber = @AccountNumber ORDER BY CreatedDate DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int loanId = Convert.ToInt32(reader["LoanId"]);
                                string loanType = reader["LoanType"].ToString()!;
                                decimal loanAmount = Convert.ToDecimal(reader["LoanAmount"]);
                                decimal interestRate = Convert.ToDecimal(reader["InterestRate"]);
                                int durationMonths = Convert.ToInt32(reader["DurationMonths"]);

                                Loan loan;

                                if (loanType == "Home")
                                {
                                    loan = new HomeLoan(accountNumber, loanAmount, interestRate, durationMonths);
                                }
                                else
                                {
                                    loan = new CarLoan(accountNumber, loanAmount, interestRate, durationMonths);
                                }

                                loan.LoanId = loanId;
                                loans.Add(loan);
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exception
            }

            return loans;
        }

        public List<Loan> GetAllLoans()
        {
            List<Loan> loans = new List<Loan>();

            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "SELECT * FROM Loans ORDER BY CreatedDate DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int loanId = Convert.ToInt32(reader["LoanId"]);
                                string accountNumber = reader["AccountNumber"].ToString()!;
                                string loanType = reader["LoanType"].ToString()!;
                                decimal loanAmount = Convert.ToDecimal(reader["LoanAmount"]);
                                decimal interestRate = Convert.ToDecimal(reader["InterestRate"]);
                                int durationMonths = Convert.ToInt32(reader["DurationMonths"]);

                                Loan loan;

                                if (loanType == "Home")
                                {
                                    loan = new HomeLoan(accountNumber, loanAmount, interestRate, durationMonths);
                                }
                                else
                                {
                                    loan = new CarLoan(accountNumber, loanAmount, interestRate, durationMonths);
                                }

                                loan.LoanId = loanId;
                                loans.Add(loan);
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exception
            }

            return loans;
        }
    }
}
