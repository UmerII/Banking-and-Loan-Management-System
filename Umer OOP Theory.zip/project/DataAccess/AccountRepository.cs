using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BankingLoanSystem.Database;
using BankingLoanSystem.Models;

namespace BankingLoanSystem.DataAccess
{
    public class AccountRepository
    {
        public bool CreateAccount(Account account)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = @"INSERT INTO Accounts (AccountNumber, HolderName, Balance, AccountType, InterestRate, OverdraftLimit)
                                   VALUES (@AccountNumber, @HolderName, @Balance, @AccountType, @InterestRate, @OverdraftLimit)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", account.AccountNumber);
                        command.Parameters.AddWithValue("@HolderName", account.HolderName);
                        command.Parameters.AddWithValue("@Balance", account.Balance);

                        if (account is SavingsAccount savings)
                        {
                            command.Parameters.AddWithValue("@AccountType", "Savings");
                            command.Parameters.AddWithValue("@InterestRate", savings.InterestRate);
                            command.Parameters.AddWithValue("@OverdraftLimit", DBNull.Value);
                        }
                        else if (account is CurrentAccount current)
                        {
                            command.Parameters.AddWithValue("@AccountType", "Current");
                            command.Parameters.AddWithValue("@InterestRate", DBNull.Value);
                            command.Parameters.AddWithValue("@OverdraftLimit", current.OverdraftLimit);
                        }

                        command.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Account? GetAccount(string accountNumber)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "SELECT * FROM Accounts WHERE AccountNumber = @AccountNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string accountType = reader["AccountType"].ToString()!;
                                string holderName = reader["HolderName"].ToString()!;
                                decimal balance = Convert.ToDecimal(reader["Balance"]);

                                if (accountType == "Savings")
                                {
                                    decimal interestRate = reader["InterestRate"] != DBNull.Value
                                        ? Convert.ToDecimal(reader["InterestRate"])
                                        : 0;

                                    return new SavingsAccount(accountNumber, holderName, balance, interestRate);
                                }
                                else if (accountType == "Current")
                                {
                                    decimal overdraftLimit = reader["OverdraftLimit"] != DBNull.Value
                                        ? Convert.ToDecimal(reader["OverdraftLimit"])
                                        : 0;

                                    return new CurrentAccount(accountNumber, holderName, balance, overdraftLimit);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exception
            }

            return null;
        }

        public bool UpdateBalance(string accountNumber, decimal newBalance)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "UPDATE Accounts SET Balance = @Balance WHERE AccountNumber = @AccountNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Balance", newBalance);
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);

                        command.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Account> GetAllAccounts()
        {
            List<Account> accounts = new List<Account>();

            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "SELECT * FROM Accounts ORDER BY CreatedDate DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string accountNumber = reader["AccountNumber"].ToString()!;
                                string accountType = reader["AccountType"].ToString()!;
                                string holderName = reader["HolderName"].ToString()!;
                                decimal balance = Convert.ToDecimal(reader["Balance"]);

                                if (accountType == "Savings")
                                {
                                    decimal interestRate = reader["InterestRate"] != DBNull.Value
                                        ? Convert.ToDecimal(reader["InterestRate"])
                                        : 0;

                                    accounts.Add(new SavingsAccount(accountNumber, holderName, balance, interestRate));
                                }
                                else if (accountType == "Current")
                                {
                                    decimal overdraftLimit = reader["OverdraftLimit"] != DBNull.Value
                                        ? Convert.ToDecimal(reader["OverdraftLimit"])
                                        : 0;

                                    accounts.Add(new CurrentAccount(accountNumber, holderName, balance, overdraftLimit));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exception
            }

            return accounts;
        }

        public bool AccountExists(string accountNumber)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = "SELECT COUNT(*) FROM Accounts WHERE AccountNumber = @AccountNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        int count = (int)command.ExecuteScalar();
                        return count > 0;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
