using System;
using System.Data.SqlClient;
using BankingLoanSystem.Database;

namespace BankingLoanSystem.DataAccess
{
    public class TransactionRepository
    {
        public bool RecordTransaction(string accountNumber, string transactionType, decimal amount, string description)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string query = @"INSERT INTO Transactions (AccountNumber, TransactionType, Amount, Description)
                                   VALUES (@AccountNumber, @TransactionType, @Amount, @Description)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        command.Parameters.AddWithValue("@TransactionType", transactionType);
                        command.Parameters.AddWithValue("@Amount", amount);
                        command.Parameters.AddWithValue("@Description", description);

                        command.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
