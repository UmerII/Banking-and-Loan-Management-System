-- =============================================
-- Banking & Loan Management System
-- Database Schema Script
-- =============================================

-- Create Accounts Table
CREATE TABLE Accounts (
    AccountNumber NVARCHAR(50) PRIMARY KEY,
    HolderName NVARCHAR(100) NOT NULL,
    Balance DECIMAL(18, 2) NOT NULL,
    AccountType NVARCHAR(50) NOT NULL,
    InterestRate DECIMAL(5, 2) NULL,
    OverdraftLimit DECIMAL(18, 2) NULL,
    CreatedDate DATETIME DEFAULT GETDATE()
);

-- Create Loans Table
CREATE TABLE Loans (
    LoanId INT IDENTITY(1,1) PRIMARY KEY,
    AccountNumber NVARCHAR(50) NOT NULL,
    LoanType NVARCHAR(50) NOT NULL,
    LoanAmount DECIMAL(18, 2) NOT NULL,
    InterestRate DECIMAL(5, 2) NOT NULL,
    DurationMonths INT NOT NULL,
    EMI DECIMAL(18, 2) NOT NULL,
    CreatedDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (AccountNumber) REFERENCES Accounts(AccountNumber)
);

-- Create Transactions Table
CREATE TABLE Transactions (
    TransactionId INT IDENTITY(1,1) PRIMARY KEY,
    AccountNumber NVARCHAR(50) NOT NULL,
    TransactionType NVARCHAR(50) NOT NULL,
    Amount DECIMAL(18, 2) NOT NULL,
    TransactionDate DATETIME DEFAULT GETDATE(),
    Description NVARCHAR(255),
    FOREIGN KEY (AccountNumber) REFERENCES Accounts(AccountNumber)
);

-- Sample Data (Optional)

-- Insert Sample Accounts
INSERT INTO Accounts (AccountNumber, HolderName, Balance, AccountType, InterestRate, OverdraftLimit)
VALUES
    ('SA001', 'John Doe', 50000.00, 'Savings', 3.5, NULL),
    ('CA001', 'Jane Smith', 75000.00, 'Current', NULL, 10000.00);

-- Insert Sample Loans
INSERT INTO Loans (AccountNumber, LoanType, LoanAmount, InterestRate, DurationMonths, EMI)
VALUES
    ('SA001', 'Home', 250000.00, 7.5, 240, 2013.27),
    ('CA001', 'Car', 30000.00, 8.5, 60, 618.30);

-- Insert Sample Transactions
INSERT INTO Transactions (AccountNumber, TransactionType, Amount, Description)
VALUES
    ('SA001', 'Deposit', 10000.00, 'Initial deposit'),
    ('SA001', 'Withdraw', 5000.00, 'ATM withdrawal'),
    ('CA001', 'Deposit', 25000.00, 'Salary credit');
