# CCP-1: Banking & Loan Management System

A fully functional Windows Forms application built with C# and .NET 8.0 demonstrating Object-Oriented Programming principles.

## Technology Stack

- **Language:** C#
- **Framework:** .NET 8.0 Windows Forms
- **Database:** SQL Server LocalDB
- **Data Access:** ADO.NET

## Features

### Account Management
- Create Savings and Current accounts
- Deposit and withdraw money
- View account balance and details
- Automatic loan eligibility calculation

### Loan Management
- Create Home and Car loans
- Calculate EMI (Equated Monthly Installment)
- Check loan eligibility
- View all loans with detailed information

### Transaction Tracking
- Automatic transaction recording
- Transaction history storage

## OOP Principles Implemented

### 1. Encapsulation
- `Account` base class with private `balance` field
- Public property accessors for controlled access

### 2. Inheritance
- `Account` (base class)
  - `SavingsAccount` (derived)
  - `CurrentAccount` (derived)
- `Loan` (abstract base class)
  - `HomeLoan` (derived)
  - `CarLoan` (derived)

### 3. Abstraction
- `Loan` abstract class with abstract `CalculateEMI()` method
- Virtual `DisplayLoanDetails()` method

### 4. Interface Implementation
- `ILoan` interface with `CalculateLoanEligibility()` method
- Implemented differently in `SavingsAccount` and `CurrentAccount`

### 5. Polymorphism
- Loans stored in `List<Loan>` collection
- Overridden methods called polymorphically
- Different EMI calculation for each loan type

## Database Schema

### Accounts Table
- AccountNumber (Primary Key)
- HolderName
- Balance
- AccountType (Savings/Current)
- InterestRate (for Savings)
- OverdraftLimit (for Current)
- CreatedDate

### Loans Table
- LoanId (Primary Key, Identity)
- AccountNumber (Foreign Key)
- LoanType (Home/Car)
- LoanAmount
- InterestRate
- DurationMonths
- EMI
- CreatedDate

### Transactions Table
- TransactionId (Primary Key, Identity)
- AccountNumber (Foreign Key)
- TransactionType
- Amount
- TransactionDate
- Description

## How to Build and Run

### Prerequisites
- Windows Operating System
- .NET 8.0 SDK or later
- SQL Server LocalDB (included with Visual Studio)

### Build Instructions

#### Option 1: Using Command Line

1. Open Command Prompt or PowerShell
2. Navigate to the project directory:
   ```
   cd /tmp/cc-agent/61833992/project
   ```

3. Restore dependencies:
   ```
   dotnet restore
   ```

4. Build the project:
   ```
   dotnet build --configuration Release
   ```

5. Run the application:
   ```
   dotnet run
   ```

#### Option 2: Using Visual Studio

1. Open Visual Studio 2022
2. Click "Open a project or solution"
3. Navigate to the project directory and select `BankingLoanSystem.csproj`
4. Press F5 or click "Start" to build and run

### Executable Location

After building, the .exe file will be located at:
```
bin/Release/net8.0-windows/BankingLoanSystem.exe
```

For debug builds:
```
bin/Debug/net8.0-windows/BankingLoanSystem.exe
```

## Usage Guide

### Creating an Account
1. Click "Create New Account"
2. Enter account number and holder name
3. Enter initial balance
4. Select account type (Savings or Current)
5. For Savings: Enter interest rate
6. For Current: Enter overdraft limit
7. Click "Create Account"

### Deposit/Withdraw
1. Click "Deposit / Withdraw"
2. Enter account number and click "Check"
3. Select transaction type
4. Enter amount
5. Click "Process Transaction"

### View Balance
1. Click "View Account Balance"
2. Enter account number
3. Click "View Details"
4. See account details and loan eligibility

### Create Loan
1. Click "Create Loan"
2. Enter account number and click "Check" to verify eligibility
3. Select loan type (Home or Car)
4. Enter loan amount, interest rate, and duration
5. Click "Calculate EMI" to preview monthly payment
6. Click "Create Loan" to finalize

### Display Loans
1. Click "Display All Loans"
2. View all loans in the grid
3. Select a loan to see detailed information
4. Click "Refresh" to update the list

## Project Structure

```
BankingLoanSystem/
│
├── Models/
│   ├── Account.cs (Base class)
│   ├── SavingsAccount.cs
│   ├── CurrentAccount.cs
│   ├── ILoan.cs (Interface)
│   ├── Loan.cs (Abstract class)
│   ├── HomeLoan.cs
│   └── CarLoan.cs
│
├── DataAccess/
│   ├── AccountRepository.cs
│   ├── LoanRepository.cs
│   └── TransactionRepository.cs
│
├── Database/
│   └── DatabaseHelper.cs
│
├── Forms/
│   ├── MainForm.cs
│   ├── CreateAccountForm.cs
│   ├── DepositWithdrawForm.cs
│   ├── ViewBalanceForm.cs
│   ├── CreateLoanForm.cs
│   └── DisplayLoansForm.cs
│
├── Program.cs
├── BankingLoanSystem.csproj
└── DatabaseScript.sql
```

## Key Features Demonstration

### Encapsulation Example
```csharp
private decimal balance;
public decimal Balance
{
    get { return balance; }
    protected set { balance = value; }
}
```

### Inheritance Example
```csharp
public class SavingsAccount : Account
{
    // Inherits AccountNumber, HolderName, Balance
    public decimal InterestRate { get; set; }
}
```

### Interface Implementation
```csharp
public class SavingsAccount : Account, ILoan
{
    public decimal CalculateLoanEligibility()
    {
        return Balance * 10; // Different logic than CurrentAccount
    }
}
```

### Abstraction Example
```csharp
public abstract class Loan
{
    public abstract decimal CalculateEMI();
}
```

### Polymorphism Example
```csharp
List<Loan> loans = new List<Loan>();
loans.Add(new HomeLoan(...));
loans.Add(new CarLoan(...));

foreach (Loan loan in loans)
{
    Console.WriteLine(loan.DisplayLoanDetails()); // Polymorphic call
}
```

## Database Connection

The application automatically creates and connects to a LocalDB database at:
```
%LocalAppData%\BankingLoanSystem\BankingDB.mdf
```

Connection string is managed in `DatabaseHelper.cs`.

## Notes

- The database is created automatically on first run
- All tables are created with proper relationships
- Transaction history is automatically maintained
- Loan eligibility is calculated based on account balance
- EMI calculation includes different logic for Home and Car loans

## Troubleshooting

### Database Connection Issues
- Ensure SQL Server LocalDB is installed
- Check if the database file has proper permissions

### Build Errors
- Verify .NET 8.0 SDK is installed
- Run `dotnet restore` to restore packages

### Runtime Errors
- Check if all form files are properly compiled
- Verify database tables are created correctly

## Author

CCP-1 Banking & Loan Management System
Developed as a demonstration of OOP principles in C#
