using System;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.DataAccess;
using BankingLoanSystem.Models;

namespace BankingLoanSystem
{
    public partial class ViewBalanceForm : Form
    {
        private TextBox txtAccountNumber = null!;
        private TextBox txtDetails = null!;
        private TextBox txtLoanEligibility = null!;

        private AccountRepository accountRepository;

        public ViewBalanceForm()
        {
            accountRepository = new AccountRepository();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "View Account Balance";
            this.Size = new Size(550, 450);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lblTitle = new Label
            {
                Text = "View Account Balance",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(150, 20),
                Size = new Size(250, 30)
            };

            Label lblAccountNumber = new Label
            {
                Text = "Account Number:",
                Location = new Point(50, 70),
                Size = new Size(120, 23)
            };

            txtAccountNumber = new TextBox
            {
                Location = new Point(180, 70),
                Size = new Size(250, 23)
            };

            Button btnView = new Button
            {
                Text = "View Details",
                Location = new Point(350, 100),
                Size = new Size(100, 25),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnView.Click += BtnView_Click;

            Label lblDetails = new Label
            {
                Text = "Account Details:",
                Location = new Point(50, 140),
                Size = new Size(120, 23),
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            txtDetails = new TextBox
            {
                Location = new Point(50, 170),
                Size = new Size(450, 100),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Color.FromArgb(245, 245, 245)
            };

            Label lblLoanEligibility = new Label
            {
                Text = "Loan Eligibility:",
                Location = new Point(50, 285),
                Size = new Size(120, 23),
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            txtLoanEligibility = new TextBox
            {
                Location = new Point(50, 310),
                Size = new Size(450, 23),
                ReadOnly = true,
                BackColor = Color.FromArgb(245, 245, 245)
            };

            Button btnClose = new Button
            {
                Text = "Close",
                Location = new Point(220, 360),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblAccountNumber);
            this.Controls.Add(txtAccountNumber);
            this.Controls.Add(btnView);
            this.Controls.Add(lblDetails);
            this.Controls.Add(txtDetails);
            this.Controls.Add(lblLoanEligibility);
            this.Controls.Add(txtLoanEligibility);
            this.Controls.Add(btnClose);

            this.BackColor = Color.White;
        }

        private void BtnView_Click(object? sender, EventArgs e)
        {
            string accountNumber = txtAccountNumber.Text.Trim();

            if (string.IsNullOrEmpty(accountNumber))
            {
                MessageBox.Show("Please enter account number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Account? account = accountRepository.GetAccount(accountNumber);

            if (account == null)
            {
                MessageBox.Show("Account not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDetails.Clear();
                txtLoanEligibility.Clear();
                return;
            }

            txtDetails.Text = account.DisplayBalance();

            if (account is ILoan loanEligible)
            {
                decimal eligibility = loanEligible.CalculateLoanEligibility();
                txtLoanEligibility.Text = $"Maximum Loan Eligible: ${eligibility:N2}";
            }
            else
            {
                txtLoanEligibility.Text = "Loan eligibility not available";
            }
        }
    }
}
