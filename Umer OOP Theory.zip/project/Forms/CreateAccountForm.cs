using System;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.DataAccess;
using BankingLoanSystem.Models;

namespace BankingLoanSystem
{
    public partial class CreateAccountForm : Form
    {
        private TextBox txtAccountNumber = null!;
        private TextBox txtHolderName = null!;
        private TextBox txtInitialBalance = null!;
        private ComboBox cmbAccountType = null!;
        private TextBox txtInterestRate = null!;
        private TextBox txtOverdraftLimit = null!;
        private Label lblInterestRate = null!;
        private Label lblOverdraftLimit = null!;

        private AccountRepository accountRepository;

        public CreateAccountForm()
        {
            accountRepository = new AccountRepository();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Create New Account";
            this.Size = new Size(500, 480);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lblTitle = new Label
            {
                Text = "Create New Account",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(140, 20),
                Size = new Size(220, 30)
            };

            Label lblAccountNumber = new Label
            {
                Text = "Account Number:",
                Location = new Point(50, 70),
                Size = new Size(120, 23)
            };

            txtAccountNumber = new TextBox
            {
                Location = new Point(180, 70),
                Size = new Size(250, 23)
            };

            Label lblHolderName = new Label
            {
                Text = "Holder Name:",
                Location = new Point(50, 110),
                Size = new Size(120, 23)
            };

            txtHolderName = new TextBox
            {
                Location = new Point(180, 110),
                Size = new Size(250, 23)
            };

            Label lblInitialBalance = new Label
            {
                Text = "Initial Balance:",
                Location = new Point(50, 150),
                Size = new Size(120, 23)
            };

            txtInitialBalance = new TextBox
            {
                Location = new Point(180, 150),
                Size = new Size(250, 23)
            };

            Label lblAccountType = new Label
            {
                Text = "Account Type:",
                Location = new Point(50, 190),
                Size = new Size(120, 23)
            };

            cmbAccountType = new ComboBox
            {
                Location = new Point(180, 190),
                Size = new Size(250, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbAccountType.Items.AddRange(new string[] { "Savings", "Current" });
            cmbAccountType.SelectedIndex = 0;
            cmbAccountType.SelectedIndexChanged += CmbAccountType_SelectedIndexChanged;

            lblInterestRate = new Label
            {
                Text = "Interest Rate (%):",
                Location = new Point(50, 230),
                Size = new Size(120, 23)
            };

            txtInterestRate = new TextBox
            {
                Location = new Point(180, 230),
                Size = new Size(250, 23),
                Text = "3.5"
            };

            lblOverdraftLimit = new Label
            {
                Text = "Overdraft Limit:",
                Location = new Point(50, 270),
                Size = new Size(120, 23),
                Visible = false
            };

            txtOverdraftLimit = new TextBox
            {
                Location = new Point(180, 270),
                Size = new Size(250, 23),
                Visible = false,
                Text = "5000"
            };

            Button btnCreate = new Button
            {
                Text = "Create Account",
                Location = new Point(120, 340),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCreate.Click += BtnCreate_Click;

            Button btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(260, 340),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCancel.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblAccountNumber);
            this.Controls.Add(txtAccountNumber);
            this.Controls.Add(lblHolderName);
            this.Controls.Add(txtHolderName);
            this.Controls.Add(lblInitialBalance);
            this.Controls.Add(txtInitialBalance);
            this.Controls.Add(lblAccountType);
            this.Controls.Add(cmbAccountType);
            this.Controls.Add(lblInterestRate);
            this.Controls.Add(txtInterestRate);
            this.Controls.Add(lblOverdraftLimit);
            this.Controls.Add(txtOverdraftLimit);
            this.Controls.Add(btnCreate);
            this.Controls.Add(btnCancel);

            this.BackColor = Color.White;
        }

        private void CmbAccountType_SelectedIndexChanged(object? sender, EventArgs e)
        {
            bool isSavings = cmbAccountType.SelectedItem?.ToString() == "Savings";

            lblInterestRate.Visible = isSavings;
            txtInterestRate.Visible = isSavings;

            lblOverdraftLimit.Visible = !isSavings;
            txtOverdraftLimit.Visible = !isSavings;
        }

        private void BtnCreate_Click(object? sender, EventArgs e)
        {
            try
            {
                string accountNumber = txtAccountNumber.Text.Trim();
                string holderName = txtHolderName.Text.Trim();
                decimal initialBalance = decimal.Parse(txtInitialBalance.Text);

                if (string.IsNullOrEmpty(accountNumber) || string.IsNullOrEmpty(holderName))
                {
                    MessageBox.Show("Please fill all required fields", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (accountRepository.AccountExists(accountNumber))
                {
                    MessageBox.Show("Account number already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Account account;

                if (cmbAccountType.SelectedItem?.ToString() == "Savings")
                {
                    decimal interestRate = decimal.Parse(txtInterestRate.Text);
                    account = new SavingsAccount(accountNumber, holderName, initialBalance, interestRate);
                }
                else
                {
                    decimal overdraftLimit = decimal.Parse(txtOverdraftLimit.Text);
                    account = new CurrentAccount(accountNumber, holderName, initialBalance, overdraftLimit);
                }

                if (accountRepository.CreateAccount(account))
                {
                    MessageBox.Show("Account created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to create account", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
