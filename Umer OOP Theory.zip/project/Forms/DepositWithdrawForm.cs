using System;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.DataAccess;
using BankingLoanSystem.Models;

namespace BankingLoanSystem
{
    public partial class DepositWithdrawForm : Form
    {
        private TextBox txtAccountNumber = null!;
        private TextBox txtAmount = null!;
        private RadioButton rbDeposit = null!;
        private RadioButton rbWithdraw = null!;
        private Label lblCurrentBalance = null!;

        private AccountRepository accountRepository;
        private TransactionRepository transactionRepository;

        public DepositWithdrawForm()
        {
            accountRepository = new AccountRepository();
            transactionRepository = new TransactionRepository();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Deposit / Withdraw";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lblTitle = new Label
            {
                Text = "Deposit / Withdraw",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(150, 20),
                Size = new Size(200, 30)
            };

            Label lblAccountNumber = new Label
            {
                Text = "Account Number:",
                Location = new Point(50, 70),
                Size = new Size(120, 23)
            };

            txtAccountNumber = new TextBox
            {
                Location = new Point(180, 70),
                Size = new Size(250, 23)
            };

            Button btnCheckBalance = new Button
            {
                Text = "Check",
                Location = new Point(350, 100),
                Size = new Size(80, 25),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCheckBalance.Click += BtnCheckBalance_Click;

            lblCurrentBalance = new Label
            {
                Text = "Current Balance: N/A",
                Location = new Point(50, 135),
                Size = new Size(380, 23),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 120, 212)
            };

            Label lblTransactionType = new Label
            {
                Text = "Transaction Type:",
                Location = new Point(50, 175),
                Size = new Size(120, 23)
            };

            rbDeposit = new RadioButton
            {
                Text = "Deposit",
                Location = new Point(180, 175),
                Size = new Size(100, 23),
                Checked = true
            };

            rbWithdraw = new RadioButton
            {
                Text = "Withdraw",
                Location = new Point(290, 175),
                Size = new Size(100, 23)
            };

            Label lblAmount = new Label
            {
                Text = "Amount:",
                Location = new Point(50, 215),
                Size = new Size(120, 23)
            };

            txtAmount = new TextBox
            {
                Location = new Point(180, 215),
                Size = new Size(250, 23)
            };

            Button btnProcess = new Button
            {
                Text = "Process Transaction",
                Location = new Point(120, 280),
                Size = new Size(150, 35),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnProcess.Click += BtnProcess_Click;

            Button btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(290, 280),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCancel.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblAccountNumber);
            this.Controls.Add(txtAccountNumber);
            this.Controls.Add(btnCheckBalance);
            this.Controls.Add(lblCurrentBalance);
            this.Controls.Add(lblTransactionType);
            this.Controls.Add(rbDeposit);
            this.Controls.Add(rbWithdraw);
            this.Controls.Add(lblAmount);
            this.Controls.Add(txtAmount);
            this.Controls.Add(btnProcess);
            this.Controls.Add(btnCancel);

            this.BackColor = Color.White;
        }

        private void BtnCheckBalance_Click(object? sender, EventArgs e)
        {
            string accountNumber = txtAccountNumber.Text.Trim();

            if (string.IsNullOrEmpty(accountNumber))
            {
                MessageBox.Show("Please enter account number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Account? account = accountRepository.GetAccount(accountNumber);

            if (account == null)
            {
                MessageBox.Show("Account not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblCurrentBalance.Text = "Current Balance: N/A";
                return;
            }

            lblCurrentBalance.Text = $"Current Balance: ${account.Balance:N2}";
        }

        private void BtnProcess_Click(object? sender, EventArgs e)
        {
            try
            {
                string accountNumber = txtAccountNumber.Text.Trim();
                decimal amount = decimal.Parse(txtAmount.Text);

                if (string.IsNullOrEmpty(accountNumber))
                {
                    MessageBox.Show("Please enter account number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Account? account = accountRepository.GetAccount(accountNumber);

                if (account == null)
                {
                    MessageBox.Show("Account not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                bool success = false;
                string transactionType = "";

                if (rbDeposit.Checked)
                {
                    account.Deposit(amount);
                    success = true;
                    transactionType = "Deposit";
                }
                else
                {
                    success = account.Withdraw(amount);
                    transactionType = "Withdraw";

                    if (!success)
                    {
                        MessageBox.Show("Insufficient balance", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                if (success)
                {
                    accountRepository.UpdateBalance(accountNumber, account.Balance);
                    transactionRepository.RecordTransaction(accountNumber, transactionType, amount, $"{transactionType} of ${amount:N2}");

                    MessageBox.Show($"{transactionType} successful!\nNew Balance: ${account.Balance:N2}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lblCurrentBalance.Text = $"Current Balance: ${account.Balance:N2}";
                    txtAmount.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
