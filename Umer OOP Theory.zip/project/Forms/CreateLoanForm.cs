using System;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.DataAccess;
using BankingLoanSystem.Models;

namespace BankingLoanSystem
{
    public partial class CreateLoanForm : Form
    {
        private TextBox txtAccountNumber = null!;
        private ComboBox cmbLoanType = null!;
        private TextBox txtLoanAmount = null!;
        private TextBox txtInterestRate = null!;
        private TextBox txtDuration = null!;
        private Label lblEMI = null!;
        private Label lblEligibility = null!;

        private AccountRepository accountRepository;
        private LoanRepository loanRepository;

        public CreateLoanForm()
        {
            accountRepository = new AccountRepository();
            loanRepository = new LoanRepository();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Create Loan";
            this.Size = new Size(550, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lblTitle = new Label
            {
                Text = "Create Loan",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(200, 20),
                Size = new Size(150, 30)
            };

            Label lblAccountNumber = new Label
            {
                Text = "Account Number:",
                Location = new Point(50, 70),
                Size = new Size(120, 23)
            };

            txtAccountNumber = new TextBox
            {
                Location = new Point(190, 70),
                Size = new Size(250, 23)
            };

            Button btnCheckEligibility = new Button
            {
                Text = "Check",
                Location = new Point(360, 100),
                Size = new Size(80, 25),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCheckEligibility.Click += BtnCheckEligibility_Click;

            lblEligibility = new Label
            {
                Text = "Loan Eligibility: N/A",
                Location = new Point(50, 135),
                Size = new Size(390, 23),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 120, 212)
            };

            Label lblLoanType = new Label
            {
                Text = "Loan Type:",
                Location = new Point(50, 170),
                Size = new Size(120, 23)
            };

            cmbLoanType = new ComboBox
            {
                Location = new Point(190, 170),
                Size = new Size(250, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbLoanType.Items.AddRange(new string[] { "Home", "Car" });
            cmbLoanType.SelectedIndex = 0;

            Label lblLoanAmount = new Label
            {
                Text = "Loan Amount:",
                Location = new Point(50, 210),
                Size = new Size(120, 23)
            };

            txtLoanAmount = new TextBox
            {
                Location = new Point(190, 210),
                Size = new Size(250, 23)
            };

            Label lblInterestRate = new Label
            {
                Text = "Interest Rate (%):",
                Location = new Point(50, 250),
                Size = new Size(120, 23)
            };

            txtInterestRate = new TextBox
            {
                Location = new Point(190, 250),
                Size = new Size(250, 23),
                Text = "7.5"
            };

            Label lblDuration = new Label
            {
                Text = "Duration (Months):",
                Location = new Point(50, 290),
                Size = new Size(130, 23)
            };

            txtDuration = new TextBox
            {
                Location = new Point(190, 290),
                Size = new Size(250, 23)
            };

            Button btnCalculateEMI = new Button
            {
                Text = "Calculate EMI",
                Location = new Point(190, 330),
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(255, 152, 0),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCalculateEMI.Click += BtnCalculateEMI_Click;

            lblEMI = new Label
            {
                Text = "Monthly EMI: --",
                Location = new Point(50, 375),
                Size = new Size(390, 23),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(46, 125, 50)
            };

            Button btnCreateLoan = new Button
            {
                Text = "Create Loan",
                Location = new Point(140, 420),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCreateLoan.Click += BtnCreateLoan_Click;

            Button btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(280, 420),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCancel.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblAccountNumber);
            this.Controls.Add(txtAccountNumber);
            this.Controls.Add(btnCheckEligibility);
            this.Controls.Add(lblEligibility);
            this.Controls.Add(lblLoanType);
            this.Controls.Add(cmbLoanType);
            this.Controls.Add(lblLoanAmount);
            this.Controls.Add(txtLoanAmount);
            this.Controls.Add(lblInterestRate);
            this.Controls.Add(txtInterestRate);
            this.Controls.Add(lblDuration);
            this.Controls.Add(txtDuration);
            this.Controls.Add(btnCalculateEMI);
            this.Controls.Add(lblEMI);
            this.Controls.Add(btnCreateLoan);
            this.Controls.Add(btnCancel);

            this.BackColor = Color.White;
        }

        private void BtnCheckEligibility_Click(object? sender, EventArgs e)
        {
            string accountNumber = txtAccountNumber.Text.Trim();

            if (string.IsNullOrEmpty(accountNumber))
            {
                MessageBox.Show("Please enter account number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Account? account = accountRepository.GetAccount(accountNumber);

            if (account == null)
            {
                MessageBox.Show("Account not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblEligibility.Text = "Loan Eligibility: N/A";
                return;
            }

            if (account is ILoan loanEligible)
            {
                decimal eligibility = loanEligible.CalculateLoanEligibility();
                lblEligibility.Text = $"Loan Eligibility: ${eligibility:N2}";
            }
            else
            {
                lblEligibility.Text = "Loan Eligibility: Not Available";
            }
        }

        private void BtnCalculateEMI_Click(object? sender, EventArgs e)
        {
            try
            {
                decimal loanAmount = decimal.Parse(txtLoanAmount.Text);
                decimal interestRate = decimal.Parse(txtInterestRate.Text);
                int duration = int.Parse(txtDuration.Text);
                string loanType = cmbLoanType.SelectedItem?.ToString() ?? "Home";

                Loan loan;

                if (loanType == "Home")
                {
                    loan = new HomeLoan("TEMP", loanAmount, interestRate, duration);
                }
                else
                {
                    loan = new CarLoan("TEMP", loanAmount, interestRate, duration);
                }

                lblEMI.Text = $"Monthly EMI: ${loan.EMI:N2}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error calculating EMI: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCreateLoan_Click(object? sender, EventArgs e)
        {
            try
            {
                string accountNumber = txtAccountNumber.Text.Trim();
                decimal loanAmount = decimal.Parse(txtLoanAmount.Text);
                decimal interestRate = decimal.Parse(txtInterestRate.Text);
                int duration = int.Parse(txtDuration.Text);
                string loanType = cmbLoanType.SelectedItem?.ToString() ?? "Home";

                if (string.IsNullOrEmpty(accountNumber))
                {
                    MessageBox.Show("Please enter account number", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Account? account = accountRepository.GetAccount(accountNumber);

                if (account == null)
                {
                    MessageBox.Show("Account not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (account is ILoan loanEligible)
                {
                    decimal eligibility = loanEligible.CalculateLoanEligibility();

                    if (loanAmount > eligibility)
                    {
                        MessageBox.Show($"Loan amount exceeds eligibility limit of ${eligibility:N2}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                Loan loan;

                if (loanType == "Home")
                {
                    loan = new HomeLoan(accountNumber, loanAmount, interestRate, duration);
                }
                else
                {
                    loan = new CarLoan(accountNumber, loanAmount, interestRate, duration);
                }

                if (loanRepository.CreateLoan(loan, loanType))
                {
                    MessageBox.Show($"Loan created successfully!\nLoan ID: {loan.LoanId}\nMonthly EMI: ${loan.EMI:N2}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to create loan", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
