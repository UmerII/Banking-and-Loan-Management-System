using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.DataAccess;
using BankingLoanSystem.Models;

namespace BankingLoanSystem
{
    public partial class DisplayLoansForm : Form
    {
        private DataGridView dgvLoans = null!;
        private TextBox txtLoanDetails = null!;

        private LoanRepository loanRepository;
        private List<Loan> loans = null!;

        public DisplayLoansForm()
        {
            loanRepository = new LoanRepository();
            InitializeComponent();
            LoadLoans();
        }

        private void InitializeComponent()
        {
            this.Text = "Display All Loans";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblTitle = new Label
            {
                Text = "All Loans",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(380, 20),
                Size = new Size(150, 30)
            };

            dgvLoans = new DataGridView
            {
                Location = new Point(20, 60),
                Size = new Size(850, 280),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White
            };
            dgvLoans.SelectionChanged += DgvLoans_SelectionChanged;

            Label lblDetails = new Label
            {
                Text = "Loan Details:",
                Location = new Point(20, 355),
                Size = new Size(120, 23),
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            txtLoanDetails = new TextBox
            {
                Location = new Point(20, 385),
                Size = new Size(850, 120),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Color.FromArgb(245, 245, 245),
                Font = new Font("Consolas", 9)
            };

            Button btnRefresh = new Button
            {
                Text = "Refresh",
                Location = new Point(350, 520),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnRefresh.Click += (s, e) => LoadLoans();

            Button btnClose = new Button
            {
                Text = "Close",
                Location = new Point(470, 520),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitle);
            this.Controls.Add(dgvLoans);
            this.Controls.Add(lblDetails);
            this.Controls.Add(txtLoanDetails);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(btnClose);

            this.BackColor = Color.White;
        }

        private void LoadLoans()
        {
            loans = loanRepository.GetAllLoans();

            dgvLoans.Columns.Clear();
            dgvLoans.Columns.Add("LoanId", "Loan ID");
            dgvLoans.Columns.Add("AccountNumber", "Account Number");
            dgvLoans.Columns.Add("LoanType", "Loan Type");
            dgvLoans.Columns.Add("LoanAmount", "Loan Amount");
            dgvLoans.Columns.Add("InterestRate", "Interest Rate (%)");
            dgvLoans.Columns.Add("DurationMonths", "Duration (Months)");
            dgvLoans.Columns.Add("EMI", "Monthly EMI");

            dgvLoans.Rows.Clear();

            foreach (Loan loan in loans)
            {
                string loanType = loan is HomeLoan ? "Home" : "Car";

                dgvLoans.Rows.Add(
                    loan.LoanId,
                    loan.AccountNumber,
                    loanType,
                    $"${loan.LoanAmount:N2}",
                    $"{loan.InterestRate}%",
                    loan.DurationMonths,
                    $"${loan.EMI:N2}"
                );
            }

            if (loans.Count == 0)
            {
                txtLoanDetails.Text = "No loans found in the system.";
            }
        }

        private void DgvLoans_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvLoans.SelectedRows.Count > 0)
            {
                int selectedIndex = dgvLoans.SelectedRows[0].Index;

                if (selectedIndex >= 0 && selectedIndex < loans.Count)
                {
                    Loan selectedLoan = loans[selectedIndex];
                    txtLoanDetails.Text = selectedLoan.DisplayLoanDetails();
                }
            }
        }
    }
}
