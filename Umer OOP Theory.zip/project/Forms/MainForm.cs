using System;
using System.Drawing;
using System.Windows.Forms;
using BankingLoanSystem.Database;

namespace BankingLoanSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            DatabaseHelper.InitializeDatabase();
        }

        private void InitializeComponent()
        {
            this.Text = "CCP-1: Banking & Loan Management System";
            this.Size = new Size(600, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            Label titleLabel = new Label
            {
                Text = "Banking & Loan Management System",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(80, 30),
                Size = new Size(450, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Button btnCreateAccount = new Button
            {
                Text = "Create New Account",
                Location = new Point(180, 100),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCreateAccount.Click += BtnCreateAccount_Click;

            Button btnDepositWithdraw = new Button
            {
                Text = "Deposit / Withdraw",
                Location = new Point(180, 160),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDepositWithdraw.Click += BtnDepositWithdraw_Click;

            Button btnViewBalance = new Button
            {
                Text = "View Account Balance",
                Location = new Point(180, 220),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(0, 120, 212),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnViewBalance.Click += BtnViewBalance_Click;

            Button btnCreateLoan = new Button
            {
                Text = "Create Loan",
                Location = new Point(180, 280),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCreateLoan.Click += BtnCreateLoan_Click;

            Button btnDisplayLoans = new Button
            {
                Text = "Display All Loans",
                Location = new Point(180, 340),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDisplayLoans.Click += BtnDisplayLoans_Click;

            Button btnExit = new Button
            {
                Text = "Exit",
                Location = new Point(180, 400),
                Size = new Size(240, 45),
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnExit.Click += (s, e) => Application.Exit();

            this.Controls.Add(titleLabel);
            this.Controls.Add(btnCreateAccount);
            this.Controls.Add(btnDepositWithdraw);
            this.Controls.Add(btnViewBalance);
            this.Controls.Add(btnCreateLoan);
            this.Controls.Add(btnDisplayLoans);
            this.Controls.Add(btnExit);

            this.BackColor = Color.FromArgb(240, 240, 240);
        }

        private void BtnCreateAccount_Click(object? sender, EventArgs e)
        {
            CreateAccountForm form = new CreateAccountForm();
            form.ShowDialog();
        }

        private void BtnDepositWithdraw_Click(object? sender, EventArgs e)
        {
            DepositWithdrawForm form = new DepositWithdrawForm();
            form.ShowDialog();
        }

        private void BtnViewBalance_Click(object? sender, EventArgs e)
        {
            ViewBalanceForm form = new ViewBalanceForm();
            form.ShowDialog();
        }

        private void BtnCreateLoan_Click(object? sender, EventArgs e)
        {
            CreateLoanForm form = new CreateLoanForm();
            form.ShowDialog();
        }

        private void BtnDisplayLoans_Click(object? sender, EventArgs e)
        {
            DisplayLoansForm form = new DisplayLoansForm();
            form.ShowDialog();
        }
    }
}
