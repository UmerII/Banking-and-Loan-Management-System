using System;

namespace BankingLoanSystem.Models
{
    public class CarLoan : Loan
    {
        public CarLoan(string accountNumber, decimal loanAmount, decimal interestRate, int durationMonths)
            : base(accountNumber, loanAmount, interestRate, durationMonths)
        {
            EMI = CalculateEMI();
        }

        public override decimal CalculateEMI()
        {
            decimal monthlyRate = (InterestRate / 12) / 100;
            decimal processingFee = LoanAmount * 0.01m;
            decimal adjustedAmount = LoanAmount + processingFee;

            if (monthlyRate == 0)
            {
                return adjustedAmount / DurationMonths;
            }

            decimal emi = (adjustedAmount * monthlyRate * (decimal)Math.Pow((double)(1 + monthlyRate), DurationMonths)) /
                         (decimal)(Math.Pow((double)(1 + monthlyRate), DurationMonths) - 1);

            return Math.Round(emi, 2);
        }

        public override string DisplayLoanDetails()
        {
            return "Car Loan\n" + base.DisplayLoanDetails() + "\nNote: Includes 1% processing fee";
        }
    }
}
