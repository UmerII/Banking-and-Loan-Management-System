using System;

namespace BankingLoanSystem.Models
{
    public abstract class Loan
    {
        public int LoanId { get; set; }
        public string AccountNumber { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal InterestRate { get; set; }
        public int DurationMonths { get; set; }
        public decimal EMI { get; protected set; }

        protected Loan(string accountNumber, decimal loanAmount, decimal interestRate, int durationMonths)
        {
            AccountNumber = accountNumber;
            LoanAmount = loanAmount;
            InterestRate = interestRate;
            DurationMonths = durationMonths;
        }

        public abstract decimal CalculateEMI();

        public virtual string DisplayLoanDetails()
        {
            return $"Loan ID: {LoanId}\nAccount: {AccountNumber}\nLoan Amount: ${LoanAmount:N2}\nInterest Rate: {InterestRate}%\nDuration: {DurationMonths} months\nEMI: ${EMI:N2}";
        }
    }
}
