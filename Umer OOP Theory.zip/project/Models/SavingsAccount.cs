using System;

namespace BankingLoanSystem.Models
{
    public class SavingsAccount : Account, ILoan
    {
        public decimal InterestRate { get; set; }

        public SavingsAccount(string accountNumber, string holderName, decimal initialBalance, decimal interestRate)
            : base(accountNumber, holderName, initialBalance)
        {
            InterestRate = interestRate;
        }

        public decimal CalculateInterest()
        {
            return Balance * (InterestRate / 100);
        }

        public void ApplyInterest()
        {
            decimal interest = CalculateInterest();
            Balance += interest;
        }

        public decimal CalculateLoanEligibility()
        {
            return Balance * 10;
        }

        public override string DisplayBalance()
        {
            return base.DisplayBalance() + $"\nAccount Type: Savings\nInterest Rate: {InterestRate}%\nInterest Earned: ${CalculateInterest():N2}";
        }
    }
}
