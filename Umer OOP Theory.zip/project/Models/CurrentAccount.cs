using System;

namespace BankingLoanSystem.Models
{
    public class CurrentAccount : Account, ILoan
    {
        public decimal OverdraftLimit { get; set; }

        public CurrentAccount(string accountNumber, string holderName, decimal initialBalance, decimal overdraftLimit)
            : base(accountNumber, holderName, initialBalance)
        {
            OverdraftLimit = overdraftLimit;
        }

        public override bool Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdrawal amount must be positive");
            }

            if (Balance + OverdraftLimit >= amount)
            {
                Balance -= amount;
                return true;
            }
            return false;
        }

        public decimal CalculateLoanEligibility()
        {
            return (Balance + OverdraftLimit) * 5;
        }

        public override string DisplayBalance()
        {
            return base.DisplayBalance() + $"\nAccount Type: Current\nOverdraft Limit: ${OverdraftLimit:N2}\nAvailable Credit: ${(Balance + OverdraftLimit):N2}";
        }
    }
}
