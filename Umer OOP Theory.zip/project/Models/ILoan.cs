namespace BankingLoanSystem.Models
{
    public interface ILoan
    {
        decimal CalculateLoanEligibility();
    }
}
