using System;

namespace BankingLoanSystem.Models
{
    public class HomeLoan : Loan
    {
        public HomeLoan(string accountNumber, decimal loanAmount, decimal interestRate, int durationMonths)
            : base(accountNumber, loanAmount, interestRate, durationMonths)
        {
            EMI = CalculateEMI();
        }

        public override decimal CalculateEMI()
        {
            decimal monthlyRate = (InterestRate / 12) / 100;

            if (monthlyRate == 0)
            {
                return LoanAmount / DurationMonths;
            }

            decimal emi = (LoanAmount * monthlyRate * (decimal)Math.Pow((double)(1 + monthlyRate), DurationMonths)) /
                         (decimal)(Math.Pow((double)(1 + monthlyRate), DurationMonths) - 1);

            return Math.Round(emi, 2);
        }

        public override string DisplayLoanDetails()
        {
            return "Home Loan\n" + base.DisplayLoanDetails() + "\nNote: Long-term financing for property purchase";
        }
    }
}
