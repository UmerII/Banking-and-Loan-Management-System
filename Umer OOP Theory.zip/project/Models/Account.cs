using System;

namespace BankingLoanSystem.Models
{
    public abstract class Account
    {
        public string AccountNumber { get; set; }
        public string HolderName { get; set; }

        private decimal balance;
        public decimal Balance
        {
            get { return balance; }
            protected set { balance = value; }
        }

        protected Account(string accountNumber, string holderName, decimal initialBalance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = initialBalance;
        }

        public virtual void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Deposit amount must be positive");
            }
            Balance += amount;
        }

        public virtual bool Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdrawal amount must be positive");
            }

            if (Balance >= amount)
            {
                Balance -= amount;
                return true;
            }
            return false;
        }

        public virtual string DisplayBalance()
        {
            return $"Account: {AccountNumber}\nHolder: {HolderName}\nBalance: ${Balance:N2}";
        }
    }
}
