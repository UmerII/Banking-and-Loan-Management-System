using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace BankingLoanSystem.Database
{
    public static class DatabaseHelper
    {
        private static string GetDatabasePath()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string dbFolder = Path.Combine(appData, "BankingLoanSystem");

            if (!Directory.Exists(dbFolder))
            {
                Directory.CreateDirectory(dbFolder);
            }

            return Path.Combine(dbFolder, "BankingDB.mdf");
        }

        public static string ConnectionString
        {
            get
            {
                string dbPath = GetDatabasePath();
                return $@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={dbPath};Integrated Security=True;Connect Timeout=30";
            }
        }

        public static void InitializeDatabase()
        {
            try
            {
                string dbPath = GetDatabasePath();

                if (!File.Exists(dbPath))
                {
                    CreateDatabase();
                }

                CreateTablesIfNotExist();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database initialization error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void CreateDatabase()
        {
            string dbPath = GetDatabasePath();
            string masterConnection = @"Data Source=(LocalDB)\MSSQLLocalDB;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection connection = new SqlConnection(masterConnection))
            {
                connection.Open();
                string createDbQuery = $@"CREATE DATABASE BankingDB ON PRIMARY
                    (NAME = BankingDB, FILENAME = '{dbPath}')";

                using (SqlCommand command = new SqlCommand(createDbQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        private static void CreateTablesIfNotExist()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string createAccountsTable = @"
                IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Accounts')
                BEGIN
                    CREATE TABLE Accounts (
                        AccountNumber NVARCHAR(50) PRIMARY KEY,
                        HolderName NVARCHAR(100) NOT NULL,
                        Balance DECIMAL(18, 2) NOT NULL,
                        AccountType NVARCHAR(50) NOT NULL,
                        InterestRate DECIMAL(5, 2) NULL,
                        OverdraftLimit DECIMAL(18, 2) NULL,
                        CreatedDate DATETIME DEFAULT GETDATE()
                    )
                END";

                string createLoansTable = @"
                IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Loans')
                BEGIN
                    CREATE TABLE Loans (
                        LoanId INT IDENTITY(1,1) PRIMARY KEY,
                        AccountNumber NVARCHAR(50) NOT NULL,
                        LoanType NVARCHAR(50) NOT NULL,
                        LoanAmount DECIMAL(18, 2) NOT NULL,
                        InterestRate DECIMAL(5, 2) NOT NULL,
                        DurationMonths INT NOT NULL,
                        EMI DECIMAL(18, 2) NOT NULL,
                        CreatedDate DATETIME DEFAULT GETDATE(),
                        FOREIGN KEY (AccountNumber) REFERENCES Accounts(AccountNumber)
                    )
                END";

                string createTransactionsTable = @"
                IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Transactions')
                BEGIN
                    CREATE TABLE Transactions (
                        TransactionId INT IDENTITY(1,1) PRIMARY KEY,
                        AccountNumber NVARCHAR(50) NOT NULL,
                        TransactionType NVARCHAR(50) NOT NULL,
                        Amount DECIMAL(18, 2) NOT NULL,
                        TransactionDate DATETIME DEFAULT GETDATE(),
                        Description NVARCHAR(255),
                        FOREIGN KEY (AccountNumber) REFERENCES Accounts(AccountNumber)
                    )
                END";

                ExecuteNonQuery(createAccountsTable, connection);
                ExecuteNonQuery(createLoansTable, connection);
                ExecuteNonQuery(createTransactionsTable, connection);
            }
        }

        private static void ExecuteNonQuery(string query, SqlConnection connection)
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.ExecuteNonQuery();
            }
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
